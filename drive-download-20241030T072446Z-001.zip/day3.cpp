#include<stdio.h>
int main()
{
	int n,c;
	scanf("%d",&n);
	for(c=0;n/10!=0;c++);
	printf("%D")
}
