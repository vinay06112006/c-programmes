#include<stdio.h>
int main()
{
int i;
for(i=97;i<=122;i++)
 printf("%c ",i);
}
