#include <stdio.h>
int main()
{
	float r,a;
	scanf("%f",&r);
	a = r*r*3.14;
	printf("area of the circle is %f",a);
	return 0;
}
