#include <stdio.h>
int main()
{
	int a=10,b=20;
	a = a+b;
	b = a-b;
	a = a-b;
	printf("a,b are %d %d",a,b);
	return 0;
	
}
