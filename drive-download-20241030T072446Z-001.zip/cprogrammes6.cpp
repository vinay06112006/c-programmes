#include<stdio.h>
#include<math.h>
int main()
{
	float a = 1.73,b = 9.36;
	printf("product of a and b in float is %f",a*b);
	printf("product of a and b in int is %f",floor(a*b));
	return 0;
}
