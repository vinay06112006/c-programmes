#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d""%d""%d",&a,&b,&c);
	if (a>b && a>c)
		printf("a is the greatest of the three numbers");
	else if (b>a && b>c)
		printf("b is the greatest of the three numbers");
	else
		printf("c is the greatest of the three numbers");
		return 0;
	
}
