#include <stdio.h>
int main()
{
	int a=5,b=9;
	printf("the sum of two numbers is %d \n",a+b);
	printf("the difference of two numbers is %d \n",a-b);
	printf("the product of two numbers is %d \n",a*b);
	printf("the quotient when a divided by b is %d \n",a/b);
	printf("the modulo of a with b is %d \n",a%b);
	return 0;
	}
	
