#include <stdio.h>
int main()
{
	float a,b,c,d,e,f;
	scanf("%f""%f""%f""%f""%f",&a,&b,&c,&d,&e);
	f = (a+b+c+d+e)/50*100;
	printf("the pecentage of marks is %f %%",f);
	return 0;
	
}
