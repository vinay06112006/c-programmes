#include<stdio.h>
int main()
{
int a,b,c;
scanf("%d""%d""%d",&a,&b,&c);
if (a==b && a==c)
	printf("the three numbers are equal");
else
	printf("the three numbers are not equal");
	
return 0;
}
