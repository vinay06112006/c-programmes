#include <stdio.h>
int main()
{
int a,b;
scanf("%d",&a);
b = a*a;
printf("area of a square of side a is %d",b);
return 0;

}
