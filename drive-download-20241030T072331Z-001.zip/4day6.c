#include<stdio.h>
#include<string.h>
int main()
{int i;
	char ch[6]="ABCDEF";
	for(i=0;i<6;i++)
	{ch[i]+=32;
	}
	puts(ch);
	
}
